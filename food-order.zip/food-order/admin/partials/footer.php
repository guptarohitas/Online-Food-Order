<!-- Footer Section Starts -->
<div class ="footer">
       <div class ="wrapper">
        <p class ="text-center">2022 All right reserved, Some Restaurant, Developed By - Rohit Gupta</p>
</div>
</div>
    <!-- Footer Secction Ends -->
</body>
</html